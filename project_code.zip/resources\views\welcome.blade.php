<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaaS POS — Run Your Store Smarter</title>

    <script>
        try {
            if (localStorage.getItem('theme') === 'dark') {
                document.documentElement.classList.add('dark');
            }
        } catch (error) {}
    </script>

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        paper: { DEFAULT: '#FAF8F2', dim: '#F1EDE2' },
                        ink: { DEFAULT: '#161B22', soft: '#2A3240' },
                        till: { 50: '#EAF6F1', 100: '#CFEBE0', 400: '#159C74', 500: '#0E7A5C', 600: '#0B6049', 700: '#084A39' },
                        stamp: { DEFAULT: '#FF5A36', dim: '#FFE4DA' },
                    },
                    fontFamily: {
                        display: ['"Space Grotesk"', 'sans-serif'],
                        body: ['"Inter"', 'sans-serif'],
                        mono: ['"IBM Plex Mono"', 'monospace'],
                    },
                    boxShadow: {
                        receipt: '0 30px 60px -20px rgba(22, 27, 34, 0.35)',
                    },
                }
            }
        }
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">

    <style>
        html { scroll-behavior: smooth; }
        body { font-family: 'Inter', sans-serif; }

        /* Receipt torn-edge */
        .torn-bottom {
            -webkit-mask-image: linear-gradient(#000, #000), radial-gradient(circle at 8px 0, transparent 8px, #000 8.5px);
            -webkit-mask-size: 100% calc(100% - 8px), 16px 8px;
            -webkit-mask-position: top left, bottom left;
            -webkit-mask-repeat: no-repeat, repeat-x;
            mask-image: linear-gradient(#000, #000), radial-gradient(circle at 8px 0, transparent 8px, #000 8.5px);
            mask-size: 100% calc(100% - 8px), 16px 8px;
            mask-position: top left, bottom left;
            mask-repeat: no-repeat, repeat-x;
        }

        /* Printing lines animation */
        @keyframes printLine {
            0% { opacity: 0; transform: translateY(-6px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .print-line { animation: printLine 0.5s ease forwards; opacity: 0; }

        @keyframes slideDown {
            0% { height: 0; }
            100% { height: var(--receipt-h, 420px); }
        }
        .receipt-unroll { animation: slideDown 1.1s cubic-bezier(.2,.8,.2,1) forwards; overflow: hidden; height: 0; }

        @keyframes floatY {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .float { animation: floatY 5s ease-in-out infinite; }

        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        .marquee-track { animation: marquee 22s linear infinite; }

        /* Scroll reveal */
        .reveal { opacity: 0; transform: translateY(22px); transition: opacity 0.7s ease, transform 0.7s ease; }
        .reveal.in-view { opacity: 1; transform: translateY(0); }

        .stagger.in-view > * { opacity: 1; transform: translateY(0); }
        .stagger > * { opacity: 0; transform: translateY(16px); transition: opacity 0.6s ease, transform 0.6s ease; }
        .stagger.in-view > *:nth-child(1) { transition-delay: 0ms; }
        .stagger.in-view > *:nth-child(2) { transition-delay: 90ms; }
        .stagger.in-view > *:nth-child(3) { transition-delay: 180ms; }
        .stagger.in-view > *:nth-child(4) { transition-delay: 270ms; }
        .stagger.in-view > *:nth-child(5) { transition-delay: 360ms; }

        .barcode { background-image: repeating-linear-gradient(90deg, currentColor 0 2px, transparent 2px 5px, currentColor 5px 6px, transparent 6px 11px); }

        details summary::-webkit-details-marker { display: none; }

        @media (prefers-reduced-motion: reduce) {
            .print-line, .receipt-unroll, .float, .marquee-track, .reveal, .stagger > * { animation: none !important; transition: none !important; opacity: 1 !important; transform: none !important; height: auto !important; }
        }
    </style>
</head>

<body class="bg-paper dark:bg-ink text-ink dark:text-paper font-body antialiased transition-colors duration-300">

    <!-- Navbar -->
    <header class="sticky top-0 z-50 border-b border-ink/10 dark:border-paper/10 bg-paper/90 dark:bg-ink/90 backdrop-blur-md">
        <div class="w-[min(1180px,calc(100%-40px))] mx-auto flex items-center justify-between min-h-[72px] gap-6">
            <a href="/" class="flex items-center gap-2 font-display font-700 text-lg tracking-tight">
                <span class="w-9 h-9 rounded-lg bg-till-500 text-paper grid place-items-center font-mono text-sm">P</span>
                SaaS<span class="text-till-500">POS</span>
            </a>

            <nav class="hidden md:flex items-center gap-8 font-mono text-[13px] uppercase tracking-wide text-ink/60 dark:text-paper/60">
                <a href="#features" class="hover:text-till-500 transition-colors">Features</a>
                <a href="#how-it-works" class="hover:text-till-500 transition-colors">How it works</a>
                <a href="#pricing" class="hover:text-till-500 transition-colors">Pricing</a>
                <a href="#faq" class="hover:text-till-500 transition-colors">FAQ</a>
            </nav>

            <div class="flex items-center gap-2">
                <button id="themeToggle" aria-label="Toggle theme" class="w-10 h-10 grid place-items-center rounded-lg border border-ink/15 dark:border-paper/15 hover:bg-ink/5 dark:hover:bg-paper/10 transition-colors">
                    <svg class="dark:hidden" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4" stroke-width="2"/><path stroke-linecap="round" stroke-width="2" d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
                    <svg class="hidden dark:block" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12.8A8.5 8.5 0 1111.2 3 6.7 6.7 0 0021 12.8z"/></svg>
                </button>

                <a href="{{ route('login') }}" class="hidden md:inline-flex px-3 py-2 font-mono text-[13px] text-ink/60 dark:text-paper/60 hover:text-ink dark:hover:text-paper transition-colors">Sign in</a>
                <a href="{{ route('business.register') }}" class="hidden md:inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-till-500 hover:bg-till-600 text-paper font-semibold text-sm transition-all hover:-translate-y-0.5 shadow-lg shadow-till-500/20">
                    Start free
                </a>

                <button id="menuToggle" aria-label="Open menu" aria-expanded="false" class="md:hidden w-10 h-10 grid place-items-center rounded-lg border border-ink/15 dark:border-paper/15">
                    <svg width="19" height="19" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-width="2" d="M4 7h16M4 12h16M4 17h16"/></svg>
                </button>
            </div>
        </div>

        <div id="mobileMenu" hidden class="md:hidden border-t border-ink/10 dark:border-paper/10 px-5 py-4 space-y-1 font-mono text-sm">
            <a href="#features" class="block py-3 border-b border-ink/10 dark:border-paper/10">Features</a>
            <a href="#how-it-works" class="block py-3 border-b border-ink/10 dark:border-paper/10">How it works</a>
            <a href="#pricing" class="block py-3 border-b border-ink/10 dark:border-paper/10">Pricing</a>
            <a href="#faq" class="block py-3 border-b border-ink/10 dark:border-paper/10">FAQ</a>
            <a href="{{ route('login') }}" class="block py-3">Sign in</a>
            <a href="{{ route('business.register') }}" class="block mt-3 text-center px-4 py-3 rounded-lg bg-till-500 text-paper font-semibold">Start free</a>
        </div>
    </header>

    <main>
        <!-- Hero -->
        <section class="relative overflow-hidden py-20 md:py-28 border-b border-ink/10 dark:border-paper/10">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto grid md:grid-cols-2 gap-16 items-center">
                <div>
                    <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-till-50 dark:bg-till-700/20 text-till-600 dark:text-till-400 font-mono text-xs uppercase tracking-wider">
                        <span class="w-1.5 h-1.5 rounded-full bg-till-500 animate-pulse"></span>
                        Every sale, accounted for
                    </div>

                    <h1 class="mt-5 font-display font-700 text-[42px] sm:text-[54px] md:text-[60px] leading-[1.05] tracking-tight max-w-xl">
                        Run your store like it prints money.
                    </h1>

                    <p class="mt-6 max-w-md text-ink/65 dark:text-paper/65 text-[17px] leading-relaxed">
                        SaaS POS keeps every sale, every item, and every rupee lined up straight —
                        so your counter moves fast and your books stay honest.
                    </p>

                    <div class="mt-8 flex flex-wrap gap-3">
                        <a href="{{ route('business.register') }}" class="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-till-500 hover:bg-till-600 text-paper font-semibold text-sm transition-all hover:-translate-y-0.5 shadow-lg shadow-till-500/25">
                            Start free trial
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14m-6-6l6 6-6 6"/></svg>
                        </a>
                        <a href="#features" class="inline-flex items-center px-6 py-3.5 rounded-lg border border-ink/15 dark:border-paper/20 font-semibold text-sm hover:bg-ink/5 dark:hover:bg-paper/10 transition-colors">
                            Explore features
                        </a>
                    </div>

                    <p class="mt-6 flex items-center gap-2 text-xs font-mono text-ink/50 dark:text-paper/50">
                        <svg width="15" height="15" fill="none" stroke="currentColor" class="text-till-500" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
                        No card required — live in under 10 minutes
                    </p>
                </div>

                <!-- Animated receipt -->
                <div class="relative flex justify-center">
                    <div class="float w-[300px] sm:w-[330px]">
                        <div class="receipt-unroll [--receipt-h:480px] bg-white text-ink shadow-receipt rounded-t-md">
                            <div class="torn-bottom bg-white px-6 pt-7 pb-6 font-mono text-[12px] leading-relaxed">
                                <p class="print-line text-center font-semibold text-[14px] tracking-widest" style="animation-delay:.2s">SAAS POS</p>
                                <p class="print-line text-center text-ink/40 text-[10px]" style="animation-delay:.35s">Main Counter · Karachi</p>
                                <p class="print-line text-center text-ink/40 text-[10px] mb-3" style="animation-delay:.45s">Thu 24 Oct · 09:41</p>

                                <div class="print-line border-t border-dashed border-ink/25 my-2" style="animation-delay:.55s"></div>

                                <div class="print-line flex justify-between" style="animation-delay:.65s"><span>Espresso beans 1kg</span><span>2,400</span></div>
                                <div class="print-line flex justify-between" style="animation-delay:.75s"><span>Ceramic mug ×2</span><span>1,850</span></div>
                                <div class="print-line flex justify-between" style="animation-delay:.85s"><span>Pour-over kit</span><span>3,600</span></div>
                                <div class="print-line flex justify-between" style="animation-delay:.95s"><span>Loyalty discount</span><span>-500</span></div>

                                <div class="print-line border-t border-dashed border-ink/25 my-2" style="animation-delay:1.05s"></div>

                                <div class="print-line flex justify-between font-semibold text-[13px]" style="animation-delay:1.15s"><span>TOTAL</span><span>Rs. 7,350</span></div>
                                <div class="print-line flex justify-between text-ink/40" style="animation-delay:1.25s"><span>Paid — Card</span><span>Approved</span></div>

                                <div class="print-line border-t border-dashed border-ink/25 my-3" style="animation-delay:1.35s"></div>
                                <div class="print-line h-6 barcode text-ink/70" style="animation-delay:1.45s"></div>
                                <p class="print-line text-center mt-2 text-[10px] text-ink/40" style="animation-delay:1.55s">Thanks for shopping with us</p>
                            </div>
                        </div>
                    </div>

                    <div class="absolute -bottom-6 -right-2 sm:right-4 bg-stamp text-white text-xs font-mono font-semibold px-3 py-2 rounded-md rotate-6 shadow-lg">
                        +12% today
                    </div>
                </div>
            </div>
        </section>

        <!-- Logo marquee -->
        <div class="py-6 border-b border-ink/10 dark:border-paper/10 overflow-hidden">
            <div class="flex whitespace-nowrap marquee-track font-mono text-xs uppercase tracking-[0.2em] text-ink/35 dark:text-paper/35 gap-14 w-max">
                <span class="flex gap-14">
                    <span>Boutiques</span><span>Cafés</span><span>Pharmacies</span><span>Hardware stores</span><span>Bakeries</span><span>Electronics shops</span><span>Salons</span>
                </span>
                <span class="flex gap-14" aria-hidden="true">
                    <span>Boutiques</span><span>Cafés</span><span>Pharmacies</span><span>Hardware stores</span><span>Bakeries</span><span>Electronics shops</span><span>Salons</span>
                </span>
            </div>
        </div>

        <!-- Features -->
        <section id="features" class="py-24 md:py-28">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto">
                <div class="reveal max-w-xl mb-14">
                    <div class="font-mono text-xs uppercase tracking-widest text-till-500">01 · Everything on one counter</div>
                    <h2 class="mt-3 font-display font-700 text-[34px] md:text-[42px] tracking-tight leading-tight">Tools your team reaches for every single shift.</h2>
                    <p class="mt-4 text-ink/60 dark:text-paper/60 text-[16px] leading-relaxed">A focused POS system built for the counter, not the boardroom.</p>
                </div>

                <div class="stagger grid md:grid-cols-3 gap-8">
                    <article class="pt-6 border-t-2 border-ink/10 dark:border-paper/15 hover:border-till-500 transition-colors duration-300">
                        <div class="w-11 h-11 rounded-lg bg-till-50 dark:bg-till-700/20 text-till-500 grid place-items-center mb-5">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                        </div>
                        <h3 class="font-display font-600 text-lg mb-2">Fast point of sale</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">Scan, discount, and print a receipt before the queue even notices — built for a busy counter, not a demo video.</p>
                    </article>

                    <article class="pt-6 border-t-2 border-ink/10 dark:border-paper/15 hover:border-till-500 transition-colors duration-300">
                        <div class="w-11 h-11 rounded-lg bg-till-50 dark:bg-till-700/20 text-till-500 grid place-items-center mb-5">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                        </div>
                        <h3 class="font-display font-600 text-lg mb-2">Accurate inventory</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">Stock updates itself with every sale, flags low shelves before they go empty, and stays in sync across locations.</p>
                    </article>

                    <article class="pt-6 border-t-2 border-ink/10 dark:border-paper/15 hover:border-till-500 transition-colors duration-300">
                        <div class="w-11 h-11 rounded-lg bg-till-50 dark:bg-till-700/20 text-till-500 grid place-items-center mb-5">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 19V5m0 14h16M8 16v-4m4 4V8m4 8v-6"/></svg>
                        </div>
                        <h3 class="font-display font-600 text-lg mb-2">Clear reporting</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">See today's sales, your best sellers, and where the money actually went — in plain numbers, not dashboards to decode.</p>
                    </article>
                </div>
            </div>
        </section>

        <!-- How it works -->
        <section id="how-it-works" class="py-24 md:py-28 bg-paper-dim dark:bg-paper/[0.03] border-y border-ink/10 dark:border-paper/10">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto">
                <div class="reveal max-w-xl mx-auto text-center mb-16">
                    <div class="font-mono text-xs uppercase tracking-widest text-till-500">02 · Setup</div>
                    <h2 class="mt-3 font-display font-700 text-[34px] md:text-[42px] tracking-tight">Open for business in three steps.</h2>
                </div>

                <div class="stagger grid md:grid-cols-3 gap-10 relative">
                    <div class="hidden md:block absolute top-5 left-[16.5%] right-[16.5%] border-t border-dashed border-ink/20 dark:border-paper/20"></div>

                    <article class="relative text-center md:text-left">
                        <div class="mx-auto md:mx-0 w-10 h-10 rounded-full bg-paper dark:bg-ink border border-till-500 text-till-500 font-mono font-semibold grid place-items-center mb-5 relative z-10">1</div>
                        <h3 class="font-display font-600 text-lg mb-2">Open your workspace</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">Register your store, set your currency and tax rules, invite your staff.</p>
                    </article>
                    <article class="relative text-center md:text-left">
                        <div class="mx-auto md:mx-0 w-10 h-10 rounded-full bg-paper dark:bg-ink border border-till-500 text-till-500 font-mono font-semibold grid place-items-center mb-5 relative z-10">2</div>
                        <h3 class="font-display font-600 text-lg mb-2">Load your shelves</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">Import products from a spreadsheet or add them by hand with prices and stock.</p>
                    </article>
                    <article class="relative text-center md:text-left">
                        <div class="mx-auto md:mx-0 w-10 h-10 rounded-full bg-paper dark:bg-ink border border-till-500 text-till-500 font-mono font-semibold grid place-items-center mb-5 relative z-10">3</div>
                        <h3 class="font-display font-600 text-lg mb-2">Ring up your first sale</h3>
                        <p class="text-ink/60 dark:text-paper/60 text-sm leading-relaxed">Every transaction lands straight in your dashboard, no end-of-day reconciling.</p>
                    </article>
                </div>
            </div>
        </section>

        <!-- Pricing -->
        <section id="pricing" class="py-24 md:py-28">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto">
                <div class="reveal max-w-xl mx-auto text-center mb-16">
                    <div class="font-mono text-xs uppercase tracking-widest text-till-500">03 · Pricing</div>
                    <h2 class="mt-3 font-display font-700 text-[34px] md:text-[42px] tracking-tight">Priced like a till, not a subscription trap.</h2>
                    <p class="mt-4 text-ink/60 dark:text-paper/60">Start free, upgrade the day your second register opens.</p>
                </div>

                <div class="stagger grid md:grid-cols-3 gap-6 items-stretch">
                    <article class="flex flex-col p-8 rounded-2xl border border-ink/10 dark:border-paper/15 bg-white dark:bg-paper/[0.03]">
                        <h3 class="font-display font-600 text-xl mb-2">Starter</h3>
                        <p class="text-ink/55 dark:text-paper/55 text-sm mb-6 min-h-[42px]">For new shops finding their feet.</p>
                        <div class="font-display font-700 text-4xl mb-6 tracking-tight">Free<span class="text-sm font-normal text-ink/50 dark:text-paper/50 font-body"> / forever</span></div>
                        <ul class="space-y-3 mb-8 flex-1 text-sm text-ink/65 dark:text-paper/65">
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Up to 50 products</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Basic point of sale</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Inventory tracking</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Email support</li>
                        </ul>
                        <a href="{{ route('business.register', ['plan' => 'starter']) }}" class="text-center px-4 py-3 rounded-lg border border-ink/15 dark:border-paper/20 font-semibold text-sm hover:bg-ink/5 dark:hover:bg-paper/10 transition-colors">Get started</a>
                    </article>

                    <article class="flex flex-col p-8 rounded-2xl border-2 border-till-500 bg-white dark:bg-paper/[0.05] relative shadow-xl shadow-till-500/10 md:-translate-y-2">
                        <span class="absolute -top-3 left-8 px-3 py-1 rounded-full bg-till-500 text-white text-xs font-mono font-semibold">Recommended</span>
                        <h3 class="font-display font-600 text-xl mb-2 mt-1">Business</h3>
                        <p class="text-ink/55 dark:text-paper/55 text-sm mb-6 min-h-[42px]">For growing teams that need real reporting.</p>
                        <div class="font-display font-700 text-4xl mb-6 tracking-tight">$29<span class="text-sm font-normal text-ink/50 dark:text-paper/50 font-body"> / month</span></div>
                        <ul class="space-y-3 mb-8 flex-1 text-sm text-ink/65 dark:text-paper/65">
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Unlimited products</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Advanced POS features</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Sales and profit reports</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Multi-user access</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Priority support</li>
                        </ul>
                        <a href="{{ route('business.register', ['plan' => 'business']) }}" class="text-center px-4 py-3 rounded-lg bg-till-500 hover:bg-till-600 text-white font-semibold text-sm transition-all hover:-translate-y-0.5 shadow-lg shadow-till-500/25">Choose Business</a>
                    </article>

                    <article class="flex flex-col p-8 rounded-2xl border border-ink/10 dark:border-paper/15 bg-white dark:bg-paper/[0.03]">
                        <h3 class="font-display font-600 text-xl mb-2">Enterprise</h3>
                        <p class="text-ink/55 dark:text-paper/55 text-sm mb-6 min-h-[42px]">For multi-store operations.</p>
                        <div class="font-display font-700 text-4xl mb-6 tracking-tight">$99<span class="text-sm font-normal text-ink/50 dark:text-paper/50 font-body"> / month</span></div>
                        <ul class="space-y-3 mb-8 flex-1 text-sm text-ink/65 dark:text-paper/65">
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Everything in Business</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Multi-store management</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Custom integrations</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Dedicated account manager</li>
                            <li class="flex gap-2"><span class="text-till-500 font-bold">✓</span>Priority phone support</li>
                        </ul>
                        <a href="{{ route('business.register', ['plan' => 'enterprise']) }}" class="text-center px-4 py-3 rounded-lg border border-ink/15 dark:border-paper/20 font-semibold text-sm hover:bg-ink/5 dark:hover:bg-paper/10 transition-colors">Contact sales</a>
                    </article>
                </div>
            </div>
        </section>

        <!-- Testimonial -->
        <section class="py-24 md:py-28 bg-paper-dim dark:bg-paper/[0.03] border-y border-ink/10 dark:border-paper/10">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto grid md:grid-cols-[0.8fr_1.2fr] gap-16 items-center">
                <div class="reveal">
                    <div class="font-mono text-xs uppercase tracking-widest text-till-500">Customer story</div>
                    <p class="font-display font-600 text-lg mt-4">Sarah Khan</p>
                    <p class="text-ink/55 dark:text-paper/55 text-sm">Owner, Fashion Boutique</p>
                    <p class="text-ink/55 dark:text-paper/55 text-sm mt-1">Retail business running on SaaS POS.</p>
                </div>
                <blockquote class="reveal font-display font-600 text-[26px] md:text-[34px] leading-snug tracking-tight">
                    "SaaS POS made our daily operations much easier. We finally have a clear view of stock, sales, and what needs attention."
                </blockquote>
            </div>
        </section>

        <!-- FAQ -->
        <section id="faq" class="py-24 md:py-28">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto">
                <div class="reveal max-w-xl mx-auto text-center mb-14">
                    <div class="font-mono text-xs uppercase tracking-widest text-till-500">FAQ</div>
                    <h2 class="mt-3 font-display font-700 text-[34px] md:text-[42px] tracking-tight">Questions before you open shop?</h2>
                </div>

                <div class="reveal max-w-2xl mx-auto divide-y divide-ink/10 dark:divide-paper/10">
                    <details class="group py-5">
                        <summary class="flex items-center justify-between gap-4 cursor-pointer font-semibold text-[15px] list-none">
                            Is there a free trial available?
                            <span class="text-till-500 text-xl group-open:rotate-45 transition-transform shrink-0">+</span>
                        </summary>
                        <p class="mt-3 text-sm text-ink/60 dark:text-paper/60 leading-relaxed max-w-xl">Yes. Start with a 14-day free trial and explore the platform before choosing a paid plan. No card required.</p>
                    </details>

                    <details class="group py-5">
                        <summary class="flex items-center justify-between gap-4 cursor-pointer font-semibold text-[15px] list-none">
                            Can I import existing products?
                            <span class="text-till-500 text-xl group-open:rotate-45 transition-transform shrink-0">+</span>
                        </summary>
                        <p class="mt-3 text-sm text-ink/60 dark:text-paper/60 leading-relaxed max-w-xl">Yes. Import products from CSV or Excel files to move your existing inventory into SaaS POS in minutes.</p>
                    </details>

                    <details class="group py-5">
                        <summary class="flex items-center justify-between gap-4 cursor-pointer font-semibold text-[15px] list-none">
                            Is my business data secure?
                            <span class="text-till-500 text-xl group-open:rotate-45 transition-transform shrink-0">+</span>
                        </summary>
                        <p class="mt-3 text-sm text-ink/60 dark:text-paper/60 leading-relaxed max-w-xl">Your data is protected with encrypted connections, strict access controls, and regular automated backups.</p>
                    </details>

                    <details class="group py-5">
                        <summary class="flex items-center justify-between gap-4 cursor-pointer font-semibold text-[15px] list-none">
                            Can I manage multiple stores?
                            <span class="text-till-500 text-xl group-open:rotate-45 transition-transform shrink-0">+</span>
                        </summary>
                        <p class="mt-3 text-sm text-ink/60 dark:text-paper/60 leading-relaxed max-w-xl">Yes, on the Enterprise plan — with centralized reporting and inventory visibility across every location.</p>
                    </details>

                    <details class="group py-5">
                        <summary class="flex items-center justify-between gap-4 cursor-pointer font-semibold text-[15px] list-none">
                            Can I change my plan later?
                            <span class="text-till-500 text-xl group-open:rotate-45 transition-transform shrink-0">+</span>
                        </summary>
                        <p class="mt-3 text-sm text-ink/60 dark:text-paper/60 leading-relaxed max-w-xl">Yes. Upgrade or downgrade any time your business needs change — no long-term lock-in.</p>
                    </details>
                </div>
            </div>
        </section>

        <!-- CTA -->
        <section class="pb-24 md:pb-28">
            <div class="w-[min(1180px,calc(100%-40px))] mx-auto">
                <div class="reveal relative overflow-hidden text-center rounded-2xl border border-ink/10 dark:border-paper/15 bg-ink dark:bg-till-700/10 text-paper px-8 py-16 md:py-20">
                    <div class="absolute inset-0 opacity-[0.06] barcode"></div>
                    <h2 class="relative font-display font-700 text-[32px] md:text-[44px] tracking-tight max-w-xl mx-auto">Ready to make closing time easier?</h2>
                    <p class="relative mt-4 max-w-md mx-auto text-paper/65 text-[15px] leading-relaxed">Bring your sales, stock, and reports into one counter-ready workspace.</p>
                    <div class="relative mt-8 flex justify-center flex-wrap gap-3">
                        <a href="{{ route('business.register') }}" class="px-6 py-3.5 rounded-lg bg-till-500 hover:bg-till-400 text-white font-semibold text-sm transition-all hover:-translate-y-0.5">Start free trial</a>
                        <a href="mailto:hello@saaspos.com?subject=Schedule%20a%20SaaS%20POS%20Demo" class="px-6 py-3.5 rounded-lg border border-paper/25 hover:bg-paper/10 font-semibold text-sm transition-colors">Schedule a demo</a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="py-9 border-t border-ink/10 dark:border-paper/10">
        <div class="w-[min(1180px,calc(100%-40px))] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <a href="/" class="flex items-center gap-2 font-display font-700">
                <span class="w-9 h-9 rounded-lg bg-till-500 text-paper grid place-items-center font-mono text-sm">P</span>
                SaaS<span class="text-till-500">POS</span>
            </a>
            <p class="text-ink/50 dark:text-paper/50 text-sm">© {{ date('Y') }} SaaS POS. All rights reserved.</p>
            <div class="flex gap-5 font-mono text-xs uppercase tracking-wide text-ink/50 dark:text-paper/50">
                <a href="#features" class="hover:text-till-500 transition-colors">Features</a>
                <a href="#pricing" class="hover:text-till-500 transition-colors">Pricing</a>
                <a href="#faq" class="hover:text-till-500 transition-colors">Support</a>
            </div>
        </div>
    </footer>

    <script>
        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        themeToggle.addEventListener('click', () => {
            const isDark = document.documentElement.classList.toggle('dark');
            try { localStorage.setItem('theme', isDark ? 'dark' : 'light'); } catch (e) {}
        });

        // Mobile menu
        const menuToggle = document.getElementById('menuToggle');
        const mobileMenu = document.getElementById('mobileMenu');
        menuToggle.addEventListener('click', () => {
            const isOpen = !mobileMenu.hasAttribute('hidden');
            if (isOpen) {
                mobileMenu.setAttribute('hidden', '');
                menuToggle.setAttribute('aria-expanded', 'false');
            } else {
                mobileMenu.removeAttribute('hidden');
                menuToggle.setAttribute('aria-expanded', 'true');
            }
        });
        document.querySelectorAll('#mobileMenu a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.setAttribute('hidden', '');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });

        // Scroll reveal
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        document.querySelectorAll('.reveal, .stagger').forEach(el => io.observe(el));
    </script>
</body>
</html>